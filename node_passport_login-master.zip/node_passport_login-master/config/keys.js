module.exports = {
  mongoURI: 'ADD_MONGO_URI_HERE'
};

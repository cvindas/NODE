require('../').register({
  transpileOnly: true
})

export function example (foo: string) {
  return foo.toUpperCase()
}

function upper (str: string) {
  return str.toUpperCase()
}

upper(10)

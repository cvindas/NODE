declare module "does-not-exist" {
  export const foobar = 'test'
}

declare function require (module: string): any

export function example () {
  return require('./example')
}

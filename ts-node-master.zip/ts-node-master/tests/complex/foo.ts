export const text = 'example'

module.exports = require('./foo').text

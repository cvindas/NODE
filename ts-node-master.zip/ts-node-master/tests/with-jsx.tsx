class Foo2 {
  render () { return <div></div> }
}

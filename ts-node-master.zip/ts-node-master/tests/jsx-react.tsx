import * as React from 'react'

const Component = props => {
  return <div />
}

export default Component

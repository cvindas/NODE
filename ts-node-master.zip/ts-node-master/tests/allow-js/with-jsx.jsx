export class Foo2 {

  static sayHi () {
    return 'hello world'
  }

  render () {
    return <div />
  }

}

import { foobar } from 'does-not-exist'

console.log(foobar)

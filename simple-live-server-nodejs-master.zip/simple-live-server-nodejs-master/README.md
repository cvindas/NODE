# This can be equivalent to use:
- python: `python -m SimpleHTTPServer`

[documentation](https://www.npmjs.com/package/live-server)

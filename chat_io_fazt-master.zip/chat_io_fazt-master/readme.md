# Tecnologías Usadas
Las siguientes herramientas son multiplataforma y gratuitas
- npm / yarn
- Node.js
  - Express.js
  - socket.io
- Jquery
- Draw.io

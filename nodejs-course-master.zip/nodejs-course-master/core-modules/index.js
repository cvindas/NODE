const os = require('os');

console.log('OS:', os.platform());
console.log('OS version:', os.release());
console.log('total Memory:', os.totalmem());
console.log('free Memory:', os.freemem());

const math = require('./math');

// add
console.log(math.add(1, 2));
console.log(math.substract(1, 2));
console.log(math.division(1, 2));
console.log(math.division(1, 0));
console.log(math.multiply(1, 2));

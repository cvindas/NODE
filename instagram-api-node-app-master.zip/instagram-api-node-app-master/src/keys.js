module.exports = {
  instagram: {
    clientId: 'b604842201a749a1b40bd52dc12c316c',
    clientSecret: '3a3d3e7f668e4782824a0c15dea2089e'
  }
};
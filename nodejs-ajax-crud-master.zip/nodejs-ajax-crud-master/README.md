#  AJAX CRUD NODEJS
this is a simple Ajax example using Nodejs and Express for backend an jquery as Frontend Library.
# NODEJS VANILLA RESTAPI
A nodejs restapi CRUD with no backend frameworks
